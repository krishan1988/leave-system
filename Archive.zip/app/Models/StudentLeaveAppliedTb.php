<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class StudentLeaveAppliedTb extends Model
{
    protected $table = 'student_leave_applied_tb';
    use HasFactory;
}
