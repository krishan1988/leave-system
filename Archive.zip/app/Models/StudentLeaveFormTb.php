<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class StudentLeaveFormTb extends Model
{
    protected $table = 'student_leave_form_tb';
    use HasFactory;
}
