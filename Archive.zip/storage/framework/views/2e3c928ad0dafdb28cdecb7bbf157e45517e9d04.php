<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.3/css/jquery.dataTables.css">
  
<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.js" defer></script>

<?php $__env->startSection('content'); ?>
    <div class="col-md-10 content">
        <div class="panel panel-default">
            <div class="panel-heading">
                Dashboard
            </div>
            <div class="panel-body">

                <div class="form-group col-md-9">

                    <table id="example" class="display" style="width:100%">
                        <thead>
                            <tr>
                                <th>Index No</th>
                                <th>Full Name</th>
                                <th>Address</th>
                                <th>Fathers Name</th>
                                <th>Contact No 1</th>
                                <th>Contact No 2</th>
                                <th>View Leave Details</th>
                            </tr>
                        </thead>
                        <tbody>
                          <?php $__currentLoopData = $studentDetail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($student->index_no); ?></td>
                                <td><?php echo e($student->full_name); ?></td>
                                <td><?php echo e($student->address); ?></td>
                                <td><?php echo e($student->fathers_name); ?></td>
                                <td><?php echo e($student->contact_no_1); ?></td>
                                <td><?php echo e($student->contact_no_2); ?></td>
                                <td><a href="<?php echo e(url('fillLeaveForm/')); ?>/<?php echo e($student->id); ?>">Apply Leave</a></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <tfoot>
                            <tr>
                              <th>Index No</th>
                              <th>Full Name</th>
                              <th>Address</th>
                              <th>Fathers Name</th>
                              <th>Contact No 1</th>
                              <th>Contact No 2</th>
                              <th>View Leave Details</th>
                            </tr>
                        </tfoot>
                    </table>
                </div>

            </div>
            <script type="text/javascript" >
                $(document).ready(function() {
    $('#example').DataTable();
} );
            </script>
        <?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/student-leave/resources/views/home.blade.php ENDPATH**/ ?>